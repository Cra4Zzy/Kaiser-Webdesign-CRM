﻿$ErrorActionPreference = "Stop"
$url = "https://crm.kaiser-webdesign.de/"
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe") | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
$base = Join-Path $env:LOCALAPPDATA "KaiserCRM"
New-Item -ItemType Directory -Path $base -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "Kaiser-CRM.ico") -Destination $base -Force
$shell = New-Object -ComObject WScript.Shell
foreach ($folder in @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Programs"))) {
 if (-not $folder) { continue }
 if ($edge) {
   $link = $shell.CreateShortcut((Join-Path $folder "Kaiser CRM.lnk"))
   $link.TargetPath = $edge
   $link.Arguments = "--app=$url"
   $link.IconLocation = (Join-Path $base "Kaiser-CRM.ico") + ",0"
   $link.Description = "Kaiser CRM Cloud - Online-Arbeitsbereich"
   $link.Save()
 } else {
   $link = $shell.CreateShortcut((Join-Path $folder "Kaiser CRM.url"))
   $link.TargetPath = $url
   $link.Save()
 }
}
Write-Host "Kaiser CRM wurde als Verknuepfung angelegt. Die Online-App muss bereits erreichbar sein."
