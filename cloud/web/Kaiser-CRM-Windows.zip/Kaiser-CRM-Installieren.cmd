@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -File "%~dp0Install-Kaiser-CRM.ps1"
if errorlevel 1 (echo Installation fehlgeschlagen. Bitte Anleitung lesen. & pause & exit /b 1)
pause
